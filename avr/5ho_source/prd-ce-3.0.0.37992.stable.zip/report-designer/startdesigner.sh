#!/bin/sh

java -XX:MaxPermSize=256m -Xms256m -Xmx768m -Dswt.swing.laf=javax.swing.plaf.metal.MetalLookAndFeel -jar launcher/launcher-1.0.0.jar org.pentaho.reportdesigner.crm.report.ReportDialog
