Copy or link one of the properties files to "repository.properties".
Then configure the settings : filename, database name, user/password that sort of thing.