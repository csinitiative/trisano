require 'ffi'
module FFI
  class Buffer
  end
end
